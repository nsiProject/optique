try:
	from data.recover import *
	from time import *
	from tkinter import *
	from tkinter import filedialog
	from PIL import *
	import platform
except ImportError:
	print("Erreur d'imporation du module de récupération de la carte...")
except Exception as error:
	print("[ERROR] : ", error)
else:
        # Parcourir les images pour ensuite la traiter et afficher les informations MAX ET NATHAN
	def selectionImage():
		try:
			global filename
			global carte
			filename = filedialog.askopenfilename(initialdir="/", title="Sélectionner une image", filetypes=(("Images au format PNG", "*.png"), ("Autres fichiers", "*.*")))
			# Modification des propriétés de l'image avec la bibliothèque pillow (python -m pip install pip wheel setuptools --upgrade et python -m pip install --upgrade pillow)
			carte = img.open(filename)
			if carte.size[0] == 400 and carte.size[1] == 300:
				carte = carte.rotate(90)
				carte = carte.rotate(180)
				left = 111
				top = 40
				right = 275
				bottom = 300
				carte = carte.crop((left, top, right, bottom))
				carte = carte.resize((800, 1300))
			else:
				print("L'image ne peut pas être traduite...")
		except IOError:
			print("Ce fichier n'est pas recevable...")
		except Exception as error:
			print("[ERROR] : {}".format(error))
		else:
			print("Fin de l'importation de l'image")
			
		
	def openFile(event):
		selectionImage()

        
	# Conversion d'un entier naturel en binaire HUGO
	def convertBinaryToDecimal(value):
		p = len(value)
		valueDecimal = 0
		index = 0
		for k in range(p, 0, -1):
			if value[index] == "1":
				valueDecimal += 2**k
			index += 1
		decimal = int(valueDecimal/2)
		return decimal

	# Récupération du code ascii du code binaire du prénom en code ASCII HUGO
	def getFirstName(binaryName):
		textName = ""
		for i in range(len(binaryName)):
			octet = binaryName[i]
			textName += str(chr(convertBinaryToDecimal(octet)))
		return str(textName)

	# Récupération du code ascii du code binaire du nom en code ASCII HUGO
	def getLastName(binaryName):
		return chr(convertBinaryToDecimal(binaryName))

	# Récupération du code ascii du code binaire de la taille en code ASCII HUGO
	def getSize(binarySize):
		return str(100 + convertBinaryToDecimal(binarySize))

	# Récupération du code ascii du code binaire de la date de naissance en code ASCII HUGO
	def getDateOfBirth(binaryDayOfBirth, binaryMonthOfBirth, binaryYearOfBirth, binaryCenturyOfBirth):
		stringDay = str(convertBinaryToDecimal(binaryDayOfBirth))
		stringMonth = str(convertBinaryToDecimal(binaryMonthOfBirth))
		stringYear = str(convertBinaryToDecimal(binaryYearOfBirth)+binaryCenturyOfBirth)
		return stringDay + "/" + stringMonth + "/" + stringYear

	# Affichage des informations de la carte après les avoir convertis HUGO
	root = Tk() # Parent
	width = 640
	height = 480
	screenWidth = root.winfo_screenwidth()
	screenHeight = root.winfo_screenheight()
	x = int((screenWidth // 2) - (width // 2))
	y = int((screenHeight // 2) - (height // 2))
	root.geometry("{}x{}+{}+{}".format(width, height, x, y))
	root.title("LECTEUR OPTIQUE")
	root.config(bg="#24292E")
	root.resizable(width=False, height=False)
	if platform.system() == "Windows":
		root.iconbitmap("lib/icon.ico")
        # Affichage des informations sur la fenêtre tkinter
	def conversion():
		label1.config(text="NOM COMPLET            : {} {}".format(getFirstName(functionRecoverFirstName(carte)), getLastName(functionRecoverLastName(carte))))
		label2.config(text="GENRE                       : {}".format(functionRecoverKind(carte)))
		label3.config(text="TAILLE                       : {} cm".format(getSize(functionRecoverSize(carte))))
		label4.config(text="DATE DE NAISSANCE    : {}".format(getDateOfBirth(functionRecoverDay(carte), functionRecoverMonth(carte), functionRecoverYear(carte), functionRecoverCentury(carte))))
	buttonGeneration = Button(root, text=("GÉNÉRER LA CONVERSION"), command=conversion, background="#FFFFFF", foreground="#000000", activebackground="#000000", activeforeground="#FFFFFF", relief="solid", font=("Helvetica", 12))
	buttonGeneration.place(x=10, y=10)
	buttonOpenImage = Button(root, text=("OUVRIR UNE IMAGE"), command=selectionImage, background="#FFFFFF", foreground="#000000", activebackground="#000000", activeforeground="#FFFFFF", relief="solid", font=("Helvetica", 12))
	buttonOpenImage.place(x=300, y=10)
	root.bind("<Control-o>", openFile)
	label1 = Label(root, text=(""), font=("Verdana", 12), background="#24292E", foreground="#FFFFFF", relief="flat")
	label2 = Label(root, text=(""), font=("Verdana", 12), background="#24292E", foreground="#FFFFFF", relief="flat")
	label3 = Label(root, text=(""), font=("Verdana", 12), background="#24292E", foreground="#FFFFFF", relief="flat")
	label4 = Label(root, text=(""), font=("Verdana", 12), background="#24292E", foreground="#FFFFFF", relief="flat")

	label1.place(x=10, y=50)
	label2.place(x=10, y=70)
	label3.place(x=10, y=90)
	label4.place(x=10, y=110)
	root.mainloop()
