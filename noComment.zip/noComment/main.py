from PIL import Image as img
import os as command

carte = img.open("img.png")
carte = carte.rotate(90)
carte = carte.rotate(180)
left = 111
top = 40
right = 275
bottom = 300
carte = carte.crop((left, top, right, bottom))
carte = carte.resize((800, 1300))


def functionRecoverFirstName(carte):
	listeTemporaire = ""
	firstName = []
	comparaisonOne = 0
	comparaisonTwo = 0
	for ligne in range(0, round(carte.size[1]/13*8), round(carte.size[1]/13)):
		for colonne in range(0, round(carte.size[0]), round(carte.size[0]/8)):
			for carreauHeight in range(ligne, ligne+round(carte.size[1]/13), 1):
				for carreauWidth in range(colonne, colonne+round(carte.size[0]/8), 1):
					color = carte.getpixel((carreauWidth, carreauHeight))
					if color[0] > 127  and color[1] > 127 and color[2] > 127:
						comparaisonOne += 1
					else:
						comparaisonTwo += 1
			if comparaisonOne > comparaisonTwo:
				listeTemporaire += "0"
			else:
				listeTemporaire += "1"
			comparaisonOne = 0
			comparaisonTwo = 0
		firstName.append(listeTemporaire)
		listeTemporaire = ""
	del listeTemporaire
	del comparaisonOne
	del comparaisonTwo
	return firstName

def functionRecoverLastName(carte):
	lastName = ""
	comparaisonOne = 0
	comparaisonTwo = 0
	for colonne in range(0, round(carte.size[0]), round(carte.size[0]/8)):
		for carreauHeight in range(round(carte.size[1]/13*8), round(carte.size[1]/13*9), 1):
			for carreauWidth in range(colonne, colonne+round(carte.size[0]/8), 1):
				color = carte.getpixel((carreauWidth, carreauHeight))
				if color[0] > 127  and color[1] > 127 and color[2] > 127:
					comparaisonOne += 1
				else:
					comparaisonTwo += 1
		if comparaisonOne > comparaisonTwo:
			lastName += "0"
		else:
			lastName += "1"
		comparaisonOne = 0
		comparaisonTwo = 0
	del comparaisonOne
	del comparaisonTwo
	return lastName

def functionRecoverDay(carte):
	day = ""
	comparaisonOne = 0
	comparaisonTwo = 0
	for colonne in range(0, round(carte.size[0]), round(carte.size[0]/8)):
		for carreauHeight in range(round(carte.size[1]/13*10), round(carte.size[1]/13*11), 1):
			for carreauWidth in range(colonne, colonne+round(carte.size[0]/8), 1):
				color = carte.getpixel((carreauWidth, carreauHeight))
				if color[0] > 127  and color[1] > 127 and color[2] > 127:
					comparaisonOne += 1
				else:
					comparaisonTwo += 1
		if comparaisonOne > comparaisonTwo:
			day += "0"
		else:
			day += "1"
		comparaisonOne = 0
		comparaisonTwo = 0
	del comparaisonOne
	del comparaisonTwo
	return day

def functionRecoverMonth(carte):
	month = ""
	comparaisonOne = 0
	comparaisonTwo = 0
	for colonne in range(0, round(carte.size[0]), round(carte.size[0]/8)):
		for carreauHeight in range(round(carte.size[1]/13*11), round(carte.size[1]/13*12), 1):
			for carreauWidth in range(colonne, colonne+round(carte.size[0]/8), 1):
				color = carte.getpixel((carreauWidth, carreauHeight))
				if color[0] > 127  and color[1] > 127 and color[2] > 127:
					comparaisonOne += 1
				else:
					comparaisonTwo += 1
		if comparaisonOne > comparaisonTwo:
			month += "0"
		else:
			month += "1"
		comparaisonOne = 0
		comparaisonTwo = 0
	del comparaisonOne
	del comparaisonTwo
	return month

def functionRecoverKind(carte):
	kind = ""
	comparaisonOne = 0
	comparaisonTwo = 0
	for ligne in range(round(carte.size[1]/13*9), round(carte.size[1]/13*10), 1):
		for colonne in range(0, round(carte.size[0]/8), 1):
			color = carte.getpixel((colonne, ligne))
			if color[0] > 127  and color[1] > 127 and color[2] > 127:
				comparaisonOne += 1
			else:
				comparaisonTwo += 1
	if comparaisonOne > comparaisonTwo:
		kind = "Homme"
		return kind
	else:
		kind = "Femme"
		return kind

def functionRecoverCentury(carte):
	century = 0
	comparaisonOne = 0
	comparaisonTwo = 0
	for ligne in range(round(carte.size[1]/13*12), carte.size[1], 1):
		for colonne in range(0, round(carte.size[0]/8), 1):
			color = carte.getpixel((colonne, ligne))
			if color[0] > 127  and color[1] > 127 and color[2] > 127:
				comparaisonOne += 1
			else:
				comparaisonTwo += 1
	if comparaisonOne > comparaisonTwo:
		century = 1900
		return century
	else:
		century = 2000
		return century

def functionRecoverSize(carte):
	size = ""
	comparaisonOne = 0
	comparaisonTwo = 0
	for colonne in range(round(carte.size[0]/8), carte.size[0], round(carte.size[0]/8)):
		for carreauHeight in range(round(carte.size[1]/13*9), round(carte.size[1]/13*10), 1):
			for carreauWidth in range(colonne, colonne+round(carte.size[0]/8), 1):
				color = carte.getpixel((carreauWidth, carreauHeight))
				if color[0] > 127  and color[1] > 127 and color[2] > 127:
					comparaisonOne += 1
				else:
					comparaisonTwo += 1
		if comparaisonOne > comparaisonTwo:
			size += "0"
		else:
			size += "1"
		comparaisonOne = 0
		comparaisonTwo = 0
	del comparaisonOne
	del comparaisonTwo
	return size

def functionRecoverYear(carte):
	year = ""
	comparaisonOne = 0
	comparaisonTwo = 0
	for colonne in range(round(carte.size[0]/8), carte.size[0], round(carte.size[0]/8)):
		for carreauHeight in range(round(carte.size[1]/13*12), carte.size[1], 1):
			for carreauWidth in range(colonne, colonne+round(carte.size[0]/8), 1):
				color = carte.getpixel((carreauWidth, carreauHeight))
				if color[0] > 127  and color[1] > 127 and color[2] > 127:
					comparaisonOne += 1
				else:
					comparaisonTwo += 1
		if comparaisonOne > comparaisonTwo:
			year += "0"
		else:
			year += "1"
		comparaisonOne = 0
		comparaisonTwo = 0
	del comparaisonOne
	del comparaisonTwo
	return year

def convertBinaryToDecimal(value):
	p = len(value)
	valueDecimal = 0
	index = 0
	for k in range(p, 0, -1):
		if value[index] == "1":
			valueDecimal += 2**k
		index += 1
	decimal = int(valueDecimal/2)
	return decimal


def getFirstName(binaryName):
	textName = ""
	for i in range(len(binaryName)):
		octet = binaryName[i]
		textName += str(chr(convertBinaryToDecimal(octet)))
	return str(textName)

def getLastName(binaryName):
	return chr(convertBinaryToDecimal(binaryName))

def getSize(binarySize):
	return str(100 + convertBinaryToDecimal(binarySize))

def getDateOfBirth(binaryDayOfBirth, binaryMonthOfBirth, binaryYearOfBirth, binaryCenturyOfBirth):
	stringDay = str(convertBinaryToDecimal(binaryDayOfBirth))
	stringMonth = str(convertBinaryToDecimal(binaryMonthOfBirth))
	stringYear = str(convertBinaryToDecimal(binaryYearOfBirth)+binaryCenturyOfBirth)
	return stringDay + "/" + stringMonth + "/" + stringYear


print("NOM COMPLET       : ", getFirstName(functionRecoverFirstName(carte)), getLastName(functionRecoverLastName(carte)))
print("GENRE             : ", functionRecoverKind(carte))
print("TAILLE            : ", getSize(functionRecoverSize(carte)), "cm")
print("DATE DE NAISSANCE : ", getDateOfBirth(functionRecoverDay(carte), functionRecoverMonth(carte), functionRecoverYear(carte), functionRecoverCentury(carte)))