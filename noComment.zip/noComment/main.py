try:
	from data.recover import *
	from time import *
except ImportError:
	print("Erreur d'imporation du module de récupération de la carte...")
except Exception as error:
	print("[ERROR] : ", error)
else:
	# Conversion d'un entier naturel en binaire
	def convertBinaryToDecimal(value):
		p = len(value)
		valueDecimal = 0
		index = 0
		for k in range(p, 0, -1):
			if value[index] == "1":
				valueDecimal += 2**k
			index += 1
		decimal = int(valueDecimal/2)
		return decimal

	# Récupération du code ascii du code binaire du prénom en code ASCII
	def getFirstName(binaryName):
		textName = ""
		for i in range(len(binaryName)):
			octet = binaryName[i]
			textName += str(chr(convertBinaryToDecimal(octet)))
		return str(textName)

	# Récupération du code ascii du code binaire du nom en code ASCII
	def getLastName(binaryName):
		return chr(convertBinaryToDecimal(binaryName))

	# Récupération du code ascii du code binaire de la taille en code ASCII
	def getSize(binarySize):
		return str(100 + convertBinaryToDecimal(binarySize))

	# Récupération du code ascii du code binaire de la date de naissance en code ASCII
	def getDateOfBirth(binaryDayOfBirth, binaryMonthOfBirth, binaryYearOfBirth, binaryCenturyOfBirth):
		stringDay = str(convertBinaryToDecimal(binaryDayOfBirth))
		stringMonth = str(convertBinaryToDecimal(binaryMonthOfBirth))
		stringYear = str(convertBinaryToDecimal(binaryYearOfBirth)+binaryCenturyOfBirth)
		return stringDay + "/" + stringMonth + "/" + stringYear
	timeTempo = localtime()
	varStart = timeTempo[3]+timeTempo[4]+timeTempo[5]
	# Affichage des informations de la carte après les avoir convertis
	print("NOM COMPLET       : ", getFirstName(functionRecoverFirstName(carte)), getLastName(functionRecoverLastName(carte)))
	print("GENRE             : ", functionRecoverKind(carte))
	print("TAILLE            : ", getSize(functionRecoverSize(carte)), "cm")
	print("DATE DE NAISSANCE : ", getDateOfBirth(functionRecoverDay(carte), functionRecoverMonth(carte), functionRecoverYear(carte), functionRecoverCentury(carte)))
	timeTempo = localtime()
	varEnd = timeTempo[3]+timeTempo[4]+timeTempo[5]
	time = varEnd-varStart
	if time > 1:
		print("Temps écoulé : ", time, "secondes")
	else:
		print("Temps écoulé :", time, "seconde")